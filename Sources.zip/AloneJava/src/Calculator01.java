import java.util.Scanner;

public class Calculator01 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String a = sc.nextLine();
		
		String[] oper = a.split("+ | - | * | / | =");
		
		String num[] = a.split("1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 0 |");
		
	}

}
