
abstract class Calculator{
	int left, right;
	
	public void setOprands(int left, int right) {
		this.left = left;
		this.right = right;
	}
	public abstract void sum();
	public abstract void avg();
	public void run(){
		sum();
		avg();
	}
}
//  run 메소드에 추상화 sum, avg

class CalculatorDemoPlus extends Calculator{
	public void sum() {
		System.out.println("+ sum :" + (this.left + this.right));
	}
	public void avg() {
		System.out.println("+ avg :" + ((this.left + this.right)/2));
	} 
}
//추상화 메소드 sum, avg 정의
class CalculatorDemoMinus extends Calculator {
	public void sum() {
		System.out.println("- sum :" + (this.left + this.right));		
	}
	public void avg() {
		System.out.println("- avg :" + ((this.left + this.right)/2));
	}
//추상화 메소드 sum, avg 정의	
}
public class CalculatorDemo {

	public static void main(String[] args) {
		CalculatorDemoPlus c1 = new CalculatorDemoPlus();
		
		c1.setOprands(10, 20);
		c1.run();
		
		CalculatorDemoMinus c2 = new CalculatorDemoMinus();
		c2.setOprands(20, 30);
		c2.run();
	}

}
