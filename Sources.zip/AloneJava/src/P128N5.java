
public class P128N5 {

	public static void main(String[] args) {
		int var1 =5;
		int var2 = 2;
		double var3 = var1 /var2;
		
		int var4 = (int)var3*var2;
		System.out.println(var4);
	}

}
