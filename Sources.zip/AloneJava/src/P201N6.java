import java.util.Scanner;

public class P201N6 {

	  public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        String str = sc.next();
	        int n = sc.nextInt();
	        
	        if(str.length() >=1 && str.length()<=10 ){
	            for(n=1; n<=5; n++){
	                System.out.print(str);
	            }
	        }
	    }

}
