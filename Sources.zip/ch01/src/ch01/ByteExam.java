package ch01;

public class ByteExam {

	public static void main(String[] args) {
		byte var1 = -128;
		byte var2 = -30;
	//	byte var3 = 128; 타입 크기 오류
		
		System.out.println("var1-> "+ var1);
		System.out.println("var2-> "+ var2);
	//	System.out.println("var3-> "+ var3);
		
	}

}
