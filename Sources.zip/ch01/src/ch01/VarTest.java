package ch01;

public class VarTest {
	
	public static void main(String[] args) {
		int a = 19;
		int b = 29;
		
		System.out.println("---------------------------");
		System.out.println("a=>"+a);
		System.out.println("b=>"+b);
		System.out.printf("a->%d b->%d",a,b);
	}
	
}

