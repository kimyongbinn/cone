package ch02;

public class BoolExam {

	public static void main(String[] args) {
		int var1 = 5;
		boolean boolVar = true; 
		
		
		// if문은 boolVar True 일 때 수행
		if(boolVar) {
			int var2;
			
			var1 = 10;
			var2 = 20;
			
			System.out.println("if var1->"+ var1);
			System.out.println("if var2->"+ var2);
			
		}
		 System.out.println("main var1->"+ var1);
		
	}

}
