package ch02;

public class StringExam {

	public static void main(String[] args) {
		String name = "김용빈";
		String job = "프로그래머";
		
		System.out.println(name);
		System.out.println(job);
	}

}
