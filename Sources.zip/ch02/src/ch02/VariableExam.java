package ch02;

public class VariableExam {

	public static void main(String[] args) {
		int Value = 10;
		
		System.out.println(Value);
		
		int result = Value + 10;
		System.out.println(result);
	}

}
