package operator;

public class ArithmeticOperatorExam {

	public static void main(String[] args) {
		int v1 = 5;
		int v2 = 2;
		
		int result1 = v1 + v2;
		System.out.println("result1 =" + result1);
		
		int result2 = v1 - v2;
		System.out.println("result2 =" + result2);
		
		int result3 = v1 * v2;
		System.out.println("result3 =" + result3);
		
		//int 나누기는 나머지 버림
		int result4 = v1 / v2;
		System.out.println("result4 =" + result4);
		
		//*** 나머지
		int result5 = v1 % v2;
		System.out.println("result5 =" + result5);
		
		//소수점           (double) 안붙히면 소수점은 잘려서 2.0으로 나옴 -> 소수점까지 원하면 double형으로 캐스팅 해야됨
		double result6 = (double) v1 / v2;
		System.out.println("result6 =" + result6);
		
	}

}
