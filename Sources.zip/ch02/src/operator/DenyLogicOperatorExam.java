package operator;

public class DenyLogicOperatorExam {

	public static void main(String[] args) {
		boolean play = true;
		System.out.println(play);
		
		play = !play;  //부정문
		System.out.println(play);
		
		play = !play;
		System.out.println(play);
	}

}
