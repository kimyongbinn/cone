package operator;
// *** 중요!
public class IncreaseDecreaseOperatorExam {

	public static void main(String[] args) {
		int x = 10;
		int y = 10;
		int z;
		int aa, bb;
		
		System.out.println("---------------");
		aa = x++; // x = x+1  1. x = aa 2. xx+ -> x+1
		bb = ++x; // 1. ++x  , 2. bb = x
		System.out.println("aa=" + aa); //10
		System.out.println("bb=" + bb); //12
		System.out.println("x=" + x);
		
		System.out.println("---------------");
		y--;
		--y;
		System.out.println("y=" + y);
		
		System.out.println("---------------");
		z= ++x + y++; // 1.  x ++ = 13   2. y = 8 3. z = 21  4. y++ (다음 넘어가서 계산됨)
		System.out.println("z=" + z);
		System.out.println("x=" + x);
		System.out.println("y=" + y);
	}

}
