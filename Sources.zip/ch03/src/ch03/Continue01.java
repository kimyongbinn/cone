package ch03;

public class Continue01 {

	public static void main(String[] args) {
		for(int i = 0; i<10; i++) {
			System.out.println("대박 i = " + i);
			if(i > 5) continue; //밑에는 실행X, 위 명령어는 실행
			System.out.println("쪽박 i = " + i);
		}
	}

}
