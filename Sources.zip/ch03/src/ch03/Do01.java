package ch03;

public class Do01 {

	public static void main(String[] args) {
		
		int sum = 0, i = 1;
		//우선 실행 후 범위 값 , while문은 범위에 안맞으면 한번도 실행 X
		do {
			sum += i;
			//System.out.println(i + "까지 합" + sum);
			i++;
		}
			while(i <= 10);
			System.out.println("합계: " + sum);
							
		}

}
