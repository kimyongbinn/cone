package ch03;

import java.util.Scanner;

public class Do03 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int cnt = 0,  num;
		int answer = (int)(Math.random()*100) + 1;
		// random값은 0.0 ~ 1.0(1.0보다 작음) 사이 값 추출해줘서 * 100 해주고 + 1 - > 1~100 값 추출  
		
		do {
			System.out.println("1~100 중 어떤 숫자일까요? ");
			num = sc.nextInt();
			
			if(answer == num) {
				System.out.println(cnt + "번에 맞췄습니다 축하!");
				break;
			}else if (answer > num) {
				System.out.println("더 큰 수를 입력하세요");
			}else System.out.println("작은 수를 입력하세요");
			
			cnt++;
			
		}while(true);
		sc.close();
	}

}
