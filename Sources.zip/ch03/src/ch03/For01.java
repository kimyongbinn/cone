package ch03;

public class For01 {

	public static void main(String[] args) {
		int sum = 0;
		//초기값은 처음만 실행, 후 범위 안에 있는지 확인 후 증강, 범위값까지 반복 후 for문 밖의 명령어 수행
		
		for(int i=1; i<=10; i++) {
			sum += i;
			// sum = sum + i
			System.out.println(i +"까지 합: "+ sum);
		}
		System.out.println("합계: " + sum);
	}

}
