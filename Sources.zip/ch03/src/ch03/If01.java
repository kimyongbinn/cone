package ch03;

public class If01 {

	public static void main(String[] args) {
		int a = -12;
		int b = 100;
		int c = 0;
		c = a + b;
		
		if (a > 0) {
			System.out.println(a +"는 양수");
			System.out.println("두줄 이상일때 {} 감싸주..");
		}
		else {
			System.out.println(a+ "는 음수"); // 두줄 이상 일때 대괄호 사용, 한줄이면 생략 가능
		}
		System.out.println("c =>" + c);
		System.out.println("프로그램 종료");
	}

}
