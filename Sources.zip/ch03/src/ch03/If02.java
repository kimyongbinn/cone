package ch03;

public class If02 {
	
	public static void main(String[] args) {
		
		// main Parameter -> Int로 변환 수행
		int a = Integer.parseInt(args[0]);
		
		if(a > 0) {
			System.out.println(a + "는 양수");
		} else {
			System.out.println(a + "는 양수");
		}
		System.out.println("프로그램 종료");
	}
}
