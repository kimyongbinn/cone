package ch03;

//import java.util.Scanner;

public class If03 {

	public static void main(String[] args)  {
		
		int score = Integer.parseInt(args[0]);
		
		/* 점수값 직접 입력
		Scanner sc = new Scanner(System.in);
		
		int score = sc.nextInt();
		*/
		
		String grade =""; //문자열 선언
		
		if(score > 90) 			grade = "A";
		else if (score >= 80)	grade = "B";
		else if (score >= 70)	grade = "C";
		else grade = "권총";
		
		System.out.println("당신 점수는 " + score + " 이고 학점은 " + grade + " 입니다.");
	}
}
