package ch03;

import java.io.IOException;

public class while02 {

	public static void main(String[] args) throws IOException {
		System.out.println("보고싶은 구구단은?");
		//시스템 키보드 값 읽음
		
		int num = System.in.read() - '0';
		
		//HW2 : while + if
		//num이 2단계에서 9단 사이일때 조회
		//아니면 구구단에 없는 숫자입니다 Message 출력
		int i = 1; 
		System.out.println("num -> " + num);
		
		if(num<=9 && num >=2) {
				while(i<=9) {
					int result = num * i;
					System.out.println(num + " * " + i + " = " + result);
					i++;
				}
		}
		else System.out.println("구구단에 없는 숫잡입니다.");
	}

}
