package ref;

public class StringEqualsExam {

	public static void main(String[] args) {
		String strVar1 = "신민철";
		String strVar2 = "신민철";
		// strVar2는 strVar1 값의 신민철을 참조해서 값을 가짐
		
		//주소번지 비교
		if(strVar1 == strVar2) {
			System.out.println("strVar1과 strVar2는 참조가 같음");
		}else {
			System.out.println("strVar1과 strVar2는 참조가 다름");
		}
		
		//문자열 비교
		if(strVar1.equals(strVar2)) {
			System.out.println("strVar1과 strVar2는 문자열이 같음");
		}
		
		// 객체Type 인스턴스    메모리 할당
		
		String strVar3 = new String("신민철");
		String strVar4 = new String("신민철");
		//strVar3과 strVar4의 메모리 할당을 따로 함.
		
		if(strVar3 == strVar4) {
			System.out.println("strVar1과 strVar2는 참조가 같음");
		}else {
			System.out.println("strVar1과 strVar2는 참조가 다름");
		}
		
		if(strVar1.equals(strVar2)) {
			System.out.println("strVar1과 strVar2는 문자열이 같음");
		}
	}

}
