package ch04;

public class ArrCopy {

	public static void main(String[] args) {
		int[] a = {1,2,3,4,5,6,7};
		int[] b = new int[10];  
		System.out.println(b);
		System.out.println("--------------1-------------");
		
		//  a의 0번부터 b의 0부터 카피하는데 a의 개수만큼 카피
		System.arraycopy(a, 0, b, 0, a.length);
		// system.arraycopy에 의해 int[] b는 {1,2,3,4,5,6,7,0,0,0}
		
		// Call by Reference -> 주소 값을 넘겨줌, 메소드 pr에 배열 int a 값을 넣음
		pr(a); 
		pr(b);
		cls(b);
		System.out.println("--------------2-------------");
		
	//  a의 0번부터 b의 2부터 카피하는데 a의 개수만큼 카피
	// { 0,0,1,2,3,4,5,6,7,0}	
		System.arraycopy(a, 0, b, 2, a.length);  
	
		pr(b);
		cls(b);
		
		System.out.println("--------------3-------------");
		
	//  a의 1번부터 b의 0부터 카피하는데 a의 개수-1 만큼 카피
	// {2,3,4,5,6,7,0,0,0,0}
		System.arraycopy(a, 1, b, 0, a.length-1);
		pr(b);
		cls(b);
		
		System.out.println("--------------4-------------");
		System.arraycopy(a, 1, b, 3, a.length-1);
		pr(b);
		cls(b);
		//{0,0,0,2,3,4,5,6,7,0}
//		kkk(35);
//		kkk3(a);
		
	}
	
	public static void kkk (int kk) {
		System.out.println("kk->" + kk);
	}
							//{1,2,3,4,5,6,7}
	public static void kkk3 (int[] a) {
		for(int i=0; i<a.length; i++) {
			System.out.print(a[i] + "\t");
		}
		System.out.println();
	}
	
	public static void pr(int[] b) {
		for(int i=0; i<b.length; i++) {
			System.out.print(b[i] + "\t");
		}
		System.out.println();
	}
	
	//모든 원소 0으로 초기화
	public static void cls(int[] arr) {
		for(int i=0; i<arr.length; i++) {
			arr[i] = 0;
		}
	}

}
