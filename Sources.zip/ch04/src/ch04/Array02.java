package ch04;

public class Array02 {

	public static void main(String[] args) {
		int a[] = new int[] {23, 45, 67, 789, 2};
		
		System.out.println(" ----------- 일반 For문 -----------");
		// for문 조회 -> 현장 work
		
		for(int i=0; i< a.length; i++) {
			System.out.println("a[" + i + "] = " + a[i]);
		}
		
		System.out.println("-----------향상형 For문-----------");
		
		//			23,45,67,789,2   1. a가 배열 처음 값을 갖음 2.kk에 a값 넣음 3.명령어 수행 4. 반복문 실행
		for(int kk : a) {
			System.out.println("kk = " + kk);
		}
	}

}
