package ch04;

public class Array03 {

	public static void main(String[] args) {
		String[] str = {"코로나", "이강인", "손흥민", "김민재", "우영우"};
		for(int i=0; i < str.length; i++) {
			System.out.println(str[i]);
		}
		
		System.out.println("-----------향상형 For문-----------");
		
		for(String kk : str) {
			System.out.println(kk);
		}
	}

}
