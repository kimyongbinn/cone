package ch04;

public class MultiArr01 {

	public static void main(String[] args) {
		int[][] score = {{80,70,90},
						 {70,90,90},
						 {80,70,80},
						 {90,90,70},
		};
		
		System.out.println("score.length-> " + score.length);
		//행의 개수
		
		
		for(int i=0; i <score.length; i++) {
			//System.out.println("score[i].length(열의 갯수)-> " + score[i].length);
			for(int j=0; j<score[i].length; j++) {
				System.out.print(score[i][j] + "\t");
			}
			System.out.println();
		}
	}
//	이름	국어	영어	수학	총점	평균	
//	--------------------------------------------
//	김준수	80	70	90	240	80
//	이하이	70	90	90	250	83
//	안예은	80	70	80	230	76
//	국카스텐	90	90	70	250	83
//	--------------------------------------------
//	총계	    320	320	330	970	80
}
