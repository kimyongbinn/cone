package ch04;

public class SumAvgMaxMin {

	public static void main(String[] args) {
		// 76,45,34,89,100,50,90,92 8개의 값을 1차원 배열로 초기화 하고 값에 
		// 합계와 평균	그리고 최대값과 최소값을 구하는 프로그램을 작성
		
		int sum = 0, avg = 0, max = 0, min = 100;
		
		int a[] = {76, 45, 34, 89, 100, 50, 90, 92};
		
		for(int i=0; i<a.length; i++) {
			sum += a[i];	
			if(a[i] > max) max = a[i]; // 맥스값에 a 배열 첫값을 넣어서 반복 재생
			if(a[i] < min) min = a[i];
		}
		avg = sum/a.length;
		
		
		
		
		System.out.println("합계 = " + sum + " 평균 = " + avg);
		System.out.println("최대값 = " + max + " 최소값 = " + min);
		
	}

}
